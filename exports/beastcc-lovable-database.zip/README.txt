This archive contains the complete development PostgreSQL export for BEASTCC.
Import development-database.sql into a new PostgreSQL database.
The export may contain private account data, password hashes, balances, orders, support records, payment settings, Telegram linkage data, and digital inventory. Treat it as confidential.
No Replit Secrets or credential values are included.
