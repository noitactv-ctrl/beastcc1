# BEASTCC transfer package

This is the application source for the BEASTCC website. The database and image assets are separate downloads because Replit limits individual attachments to 100 MB.

## Download all parts

- `beastcc-lovable-source.zip` — source code, configuration, and package files
- `beastcc-lovable-database.zip` — complete development PostgreSQL schema and data export
- `beastcc-lovable-assets-1.zip`, `beastcc-lovable-assets-2.zip`, `beastcc-lovable-assets-3.zip` — all image/text assets

Extract the source archive first, then extract each assets archive into the same source directory. They all contain an `attached_assets/` folder; allow files to merge.

## Database import

Import `development-database.sql` into a PostgreSQL database in the new project. It includes the complete development database schema and records.

## Security

The database export may contain private account data, password hashes, balances, orders, support records, payment settings, Telegram linkage data, and digital inventory. Treat these files as confidential. Reconfigure all credentials and provider keys in the new project; no Replit Secrets or credential values are included in these archives.

## Setup

Install dependencies from `package.json`, use `.env.example` as a variable-name guide, and use the existing scripts for development and production builds. Do not reuse old session or provider credentials.
