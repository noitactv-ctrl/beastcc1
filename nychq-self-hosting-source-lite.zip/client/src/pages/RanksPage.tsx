import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";

const RANKS = [
  { key: "newbie",  label: "Newbie",  emoji: "🌱", color: "text-white/45",   bar: "#ffffff40", border: "border-white/10",     glow: "",                     discount: 0,  threshold: 0,      next: 10000  },
  { key: "regular", label: "Regular", emoji: "⭐", color: "text-blue-400",   bar: "#60a5fa",   border: "border-blue-500/30",  glow: "shadow-blue-500/10",   discount: 2,  threshold: 10000,  next: 50000  },
  { key: "vip",     label: "VIP",     emoji: "💎", color: "text-purple-400", bar: "#c084fc",   border: "border-purple-500/30",glow: "shadow-purple-500/10", discount: 5,  threshold: 50000,  next: 100000 },
  { key: "nyc",     label: "NYC",     emoji: "🗽", color: "text-amber-400",  bar: "#fbbf24",   border: "border-amber-500/30", glow: "shadow-amber-500/10",  discount: 10, threshold: 100000, next: null   },
];

function getRankIdx(totalDeposited: number) {
  if (totalDeposited >= 100000) return 3;
  if (totalDeposited >= 50000)  return 2;
  if (totalDeposited >= 10000)  return 1;
  return 0;
}

export default function RanksPage() {
  const { data: rankData, isLoading } = useQuery<any>({ queryKey: ["/api/user/rank"] });

  const totalDeposited = rankData?.totalDeposited ?? 0;
  const currentIdx = getRankIdx(totalDeposited);
  const current = RANKS[currentIdx];
  const next = RANKS[currentIdx + 1] ?? null;
  const progress = next
    ? Math.min(100, Math.round(((totalDeposited - current.threshold) / (next.threshold - current.threshold)) * 100))
    : 100;

  return (
    <div className="pixel-page min-h-screen pb-10">
      <div className="pixel-page pt-2">

        {/* ── Hero ── */}
        <div className="pt-2 pb-5 space-y-1">
          <p className="pixel-text text-[9px] text-[#ffe177]">REWARDS / MEMBER STATUS</p>
          <h1 className="mt-3 text-xl leading-relaxed text-white sm:text-2xl">RANK</h1>
        </div>

        <div className="mb-6">
          <div>
            <h2 className="pixel-text text-[9px] text-white">YOUR TIER</h2>
            <p className="text-[10px] text-white/50 uppercase tracking-widest">Deposit more, save more</p>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-16">
            <Loader2 className="h-5 w-5 animate-spin text-primary" />
          </div>
        ) : (
          <>
            {/* Current rank hero */}
            <div className={`pixel-panel ${current.border} bg-[#19367f] p-5 mb-5 shadow-lg ${current.glow}`}>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <span className="grid h-14 w-14 place-items-center border-[3px] border-black bg-[#10215e] text-3xl">{current.emoji}</span>
                  <div>
                    <p className={`text-lg font-bold ${current.color}`}>{current.label}</p>
                    <p className="pixel-text text-[7px] text-[#c5d6ff]">TIER {currentIdx + 1} OF {RANKS.length}</p>
                  </div>
                </div>
                <div className="text-right">
                  {current.discount > 0 ? (
                    <>
                      <p className={`text-2xl font-bold ${current.color}`}>{current.discount}%</p>
                      <p className="text-[10px] text-white/55">shop-wide discount</p>
                    </>
                  ) : (
                    <>
                      <p className="text-2xl font-bold text-white/30">—</p>
                      <p className="text-[10px] text-white/40">no discount yet</p>
                    </>
                  )}
                </div>
              </div>

              {next ? (
                <div className="space-y-2">
                  <div className="flex justify-between text-[10px] text-white/40">
                    <span>${(totalDeposited / 100).toFixed(0)} deposited</span>
                    <span>${(next.threshold / 100).toFixed(0)} for {next.label} {next.emoji}</span>
                  </div>
                  <div className="h-3 border-[2px] border-black bg-[#0a1645] overflow-hidden">
                    <div
                      className="h-full rounded-full transition-[width] duration-700 ease-out"
                      style={{ width: `${progress}%`, backgroundColor: current.bar }}
                    />
                  </div>
                  <p className="text-[10px] text-white/30">
                    ${((next.threshold - totalDeposited) / 100).toFixed(0)} more to unlock {next.discount}% discount
                  </p>
                </div>
              ) : (
                <p className="text-[11px] text-amber-400/60 mt-2">Max rank reached — {current.discount}% discount on every order automatically</p>
              )}
            </div>

            {/* All tiers */}
            <div className="space-y-3">
              <p className="pixel-label">ALL TIERS</p>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {RANKS.map((rank, i) => {
                const isUnlocked = i <= currentIdx;
                const isCurrent = i === currentIdx;
                return (
                  <div
                    key={rank.key}
                    className={`flex flex-col items-center justify-center gap-2 px-4 py-4 border-[3px] border-black transition-all ${
                      isCurrent
                        ? "bg-[#1f439b] ring-2 ring-[#e5be35]"
                        : isUnlocked
                        ? "bg-[#10215e]"
                        : "bg-[#0b153d] opacity-50"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="grid h-9 w-9 place-items-center border-2 border-black bg-[#0b153d] text-lg">{rank.emoji}</span>
                      <div>
                        <p className={`text-sm font-bold ${isUnlocked ? rank.color : "text-white/40"}`}>
                          {rank.label}
                          {isCurrent && <span className="ml-2 text-[9px] font-normal text-white/40 uppercase tracking-widest">current</span>}
                        </p>
                        <p className="text-[10px] text-white/30">
                          {rank.threshold === 0 ? "Default" : `$${(rank.threshold / 100).toFixed(0)}+ deposited`}
                        </p>
                      </div>
                    </div>
                    <div className="text-center">
                      {rank.discount > 0 ? (
                        <span className={`text-sm font-bold ${isUnlocked ? rank.color : "text-white/30"}`}>{rank.discount}% off</span>
                      ) : (
                        <span className="text-sm text-white/30">—</span>
                      )}
                    </div>
                  </div>
                );
              })}
              </div>
            </div>

            <p className="text-[10px] text-white/30 text-center mt-6 leading-relaxed">
              Discounts apply automatically at checkout.<br />Based on your total lifetime deposits.
            </p>
          </>
        )}
      </div>
    </div>
  );
}
